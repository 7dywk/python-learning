/* ============================================================
   ВСІ ДАНІ САЙТУ. Верстку чіпати не треба.
   Нова робота = один новий рядок у works.
   img: "assets/works/назва.jpg"  (16:9, 1280x720). Порожній рядок = темна заглушка.
   Підключено як звичайний <script>, тому працює і без сервера.
   ============================================================ */
window.PORTFOLIO = {
  site: {
    // Куди веде кнопка "Замовити прев'ю"
    order: "https://docs.google.com/forms/d/e/1FAIpQLSdNbeK2zbD4Rl0LVmkMP1Cmz4TDLRD8ym3yptAXsV3DFJqJcw/viewform"
  },

  // Цифри для Bento-сітки (зараз приклади, постав свої реальні)
  stats: { ctr: "+4.8%", views: "50M+", speed: "24" },

  // Lottie для Bento-клітинки. Шлях до .lottie або .json з IconScout. "" = порожня рамка
  lottie: { bento: "" },

  // Софт у Bento. icon: шлях до .svg / .lottie з IconScout. "" = буквений значок
  tools: [
    { name: "Photoshop",     short: "Ps", icon: "" },
    { name: "Blender",       short: "Bl", icon: "" },
    { name: "After Effects", short: "Ae", icon: "" }
  ],

  // cat створює таб автоматично. views: приклади, заміни на реальні
  works: [
    { title: "Am I on a deserted island? Hand Simulator: Survival", cat: "Gaming",          views: "1.2M", img: "" },
    { title: "I Built a Time Machine and This Happened",            cat: "Gaming",          views: "860K", img: "" },
    { title: "The house robbery didn't go according to plan",       cat: "Gaming",          views: "540K", img: "" },
    { title: "We made burgers from random ingredients",             cat: "IRL / Vlogs",     views: "310K", img: "" },
    { title: "I Cooked Food From Every Country",                    cat: "IRL / Vlogs",     views: "720K", img: "" },
    { title: "I Tried Flipping Cars With No Experience",            cat: "IRL / Vlogs",     views: "450K", img: "" },
    { title: "Як я заробив $10 000 на подарунках в Telegram",       cat: "Business & Crypto", views: "980K", img: "" },
    { title: "100.000 ГРН на монтажі відео в 17 років",             cat: "Business & Crypto", views: "640K", img: "" },
    { title: "How to make money editing videos",                    cat: "Business & Crypto", views: "270K", img: "" }
  ],

  // Пари До / Після (показується 3). before = сирий вихідник, after = готове прев'ю
  compare: [
    { title: "Gaming",            before: "", after: "" },
    { title: "IRL / Vlogs",       before: "", after: "" },
    { title: "Business & Crypto", before: "", after: "" }
  ],

  // handle копіюється кнопкою. Заміни Discord на свій
  socials: [
    { name: "Telegram",  url: "https://t.me/illiasoo",                   handle: "@illiasoo" },
    { name: "Discord",   url: "https://discord.com/users/YOUR_ID",       handle: "your_discord" },
    { name: "Instagram", url: "https://www.instagram.com/cosmotyp3/",    handle: "@cosmotyp3" },
    { name: "Behance",   url: "https://www.behance.net/illiaso",         handle: "illiaso" }
  ]
};
